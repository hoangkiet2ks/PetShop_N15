import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import EventData from "./EventData";

import "../../css/news/NewsEvent1.css";
import "../../css/news/NewsEvent2.css";
import "../../css/news/NewsEvent3.css";
import "../../css/news/NewsEvent6.css";

const NewsEvent = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const data = EventData[eventId];
  const id = parseInt(eventId);

  useEffect(() => {
    if (eventId === "6" || eventId === "8") {
      const createBalloons = () => {
        const container = document.querySelector(".balloon-container");
        if (!container) return;

        for (let i = 0; i < 10; i++) {
          const balloon = document.createElement("div");
          balloon.className = "balloon";
          balloon.style.left = `${Math.random() * 100}%`;
          balloon.style.animationDuration = `${4 + Math.random() * 4}s`;
          container.appendChild(balloon);
          setTimeout(() => {
            balloon.remove();
          }, 8000);
        }
      };

      const interval = setInterval(createBalloons, 1500);
      return () => clearInterval(interval);
    }
  }, [eventId]);

  if (!data) return <div className="text-center p-4 text-lg text-red-500">❌ Sự kiện không tồn tại</div>;

  return (
    <div className={`background-container ${data.cssClass}`}>
      {data.content}

      {/* Nút điều hướng sự kiện */}
      <div className="text-center mt-5 d-flex justify-content-center gap-3 flex-wrap">
        <button
          onClick={() => navigate(`/news-event/${id - 1}`)}
          disabled={id <= 1}
          className="btn btn-warning"
          style={{ width: "300px", height:50 }}
        >
          ⬅ Sự kiện trước
        </button>
        <button
          onClick={() => navigate(`/news-event/${id + 1}`)}
          disabled={id >= 8}
          className="btn btn-success"
          style={{ width: "300px",  height:50, marginBottom:20 }}
        >
          Sự kiện tiếp theo ➡
        </button>
      </div>
    </div>
  );
};

export default NewsEvent;
